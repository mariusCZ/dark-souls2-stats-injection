#pragma once

#include <Windows.h>
#include <wchar.h>

typedef unsigned long Address;
typedef Address Count;
typedef Address Offset;

DWORD get_PID(wchar_t PrName[]);
DWORD GetModuleBase(wchar_t lpModuleName[], DWORD dwProcessId);
DWORD InjectRoutine(HANDLE hProc, Address base);
Address CalcPtr_Ext(HANDLE hProc, Address base, Offset offs[], Count lvl);

wchar_t PrName[] = L"DarkSoulsII.exe";
Address HpAddress = 0x01150414;
Offset HpOffsets[] = { 0x74, 0xB8, 0x08, 0x14, 0x04, 0x04, 0xFC };
Offset DeathOffsets[] = { 0x74, 0xC, 0x08, 0x08, 0x10, 0x04, 0x1E0 };
Address HookAddr = 0x126388;