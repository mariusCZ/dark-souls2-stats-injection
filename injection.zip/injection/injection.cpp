// injection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <Windows.h>
#include <wchar.h>
#include <stdio.h>
#include <tlhelp32.h>
#include "injection.h"

int main()
{
    DWORD PID;
    HANDLE hProcess;
    DWORD BaseAddress;
    DWORD DmgAddress;

    Address finalHP = 0;
    Address finalDeath = 0;
    unsigned int resultHP = 0;
    unsigned int resultDMG = 0;
    unsigned int resultDeath = 0;
    unsigned char resAssert = 0;

    if (!(PID = get_PID(PrName)))
    {
        printf("Process does not exist\n");
        system("pause");
        return 1;
    }
    printf("Process founded!\n");
    printf("Process name: %s\n", PrName);
    printf("PID: %d\n\n", PID);

    if (!(hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, PID)))
    {
        printf("OpenProcess error\n");
        return 1;
    }

    printf("OpenProcess is ok\n");
    printf("Now we have handle of process %s\n", PrName);
    printf("Handle: %d\n\n", hProcess);

    if (!(BaseAddress = GetModuleBase(PrName, PID)))
    {
        printf("GetModuleBase error\n");
        return 1;
    }
    printf("GetModuleBase is ok\n");
    printf("BaseAddress: %x\n\n", BaseAddress);

    finalHP = CalcPtr_Ext(hProcess, BaseAddress+HpAddress, HpOffsets, 7);
    finalDeath = CalcPtr_Ext(hProcess, BaseAddress + HpAddress, DeathOffsets, 7);
    
    ReadProcessMemory(hProcess, (LPCVOID)(BaseAddress + HookAddr), &resAssert, 1, 0);
    if(resAssert != 0x68)
        DmgAddress = InjectRoutine(hProcess, BaseAddress);
    while (1) {
        ReadProcessMemory(hProcess, (LPCVOID)finalHP, &resultHP, sizeof(int), 0);
        ReadProcessMemory(hProcess, (LPCVOID)finalDeath, &resultDeath, sizeof(int), 0);
        ReadProcessMemory(hProcess, (LPCVOID)DmgAddress, &resultDMG, sizeof(int), 0);

        printf("Health: %d\n", resultHP);
        printf("Deaths: %d\n", resultDeath);
        printf("Damage: %d\n", resultDMG);
        Sleep(500);
    }

    return 0;
}

DWORD get_PID(wchar_t PrName[])
{
    PROCESSENTRY32 entry;
    entry.dwSize = sizeof(PROCESSENTRY32);
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    if (Process32First(snapshot, &entry) == TRUE)
    {
        while (Process32Next(snapshot, &entry) == TRUE)
        {
            //printf("%s\n", entry.szExeFile);
            if (wcscmp(entry.szExeFile, PrName) == 0)
            {
                return entry.th32ProcessID;
            }
        }
    }
    CloseHandle(snapshot);
    return NULL;
}

DWORD GetModuleBase(wchar_t lpModuleName[], DWORD dwProcessId)
{
    MODULEENTRY32 lpModuleEntry = { 0 };
    HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessId);

    if (!hSnapShot)
        return NULL;
    lpModuleEntry.dwSize = sizeof(lpModuleEntry);
    BOOL bModule = Module32First(hSnapShot, &lpModuleEntry);
    while (bModule)
    {
        if (!wcscmp(lpModuleEntry.szModule, lpModuleName))
        {
            CloseHandle(hSnapShot);
            return (DWORD)lpModuleEntry.modBaseAddr;
        }
        bModule = Module32Next(hSnapShot, &lpModuleEntry);
    }
    CloseHandle(hSnapShot);
    return NULL;
}

DWORD InjectRoutine(HANDLE hProc, Address base)
{
    char HookShellcode[8] = { 0 };
    char InjectShellcode[128] = { 0 };
    DWORD pInjectedFunction = (DWORD)VirtualAllocEx(hProc, NULL, 128, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    DWORD pVar = (DWORD)VirtualAllocEx(hProc, NULL, 4, MEM_COMMIT, PAGE_READWRITE);
    DWORD addrTest = 0x112233;
    DWORD HookAddr = 0x126388;

    const unsigned char iCode[] = {0x89, 0x0B, 0x5B, 0x89, 0x46, 0x14, 0xF3, 0x0F, 0x11, 0x46, 0x2C};

    memcpy(HookShellcode, "\x68", 1);
    memcpy(HookShellcode+1, &pInjectedFunction, sizeof(DWORD));
    memcpy(HookShellcode+5, "\xc3\x66\x90", 3);

    memcpy(InjectShellcode, "\x53\xbb", 2);
    memcpy(InjectShellcode+2, &pVar, sizeof(DWORD));
    memcpy(InjectShellcode+6, &iCode, sizeof(iCode));
    memcpy(InjectShellcode+6+sizeof(iCode), "\x68", 1);
    DWORD retAddr = base + 0x126390;
    memcpy(InjectShellcode+6+sizeof(iCode)+1, &retAddr, sizeof(DWORD));
    memcpy(InjectShellcode+6+sizeof(iCode)+5, "\xc3\x66\x90", 3);

    WriteProcessMemory(hProc, (LPVOID)(pInjectedFunction), InjectShellcode, sizeof(InjectShellcode), 0);
    WriteProcessMemory(hProc, (LPVOID)(base + 0x126388), HookShellcode, sizeof(HookShellcode), 0);
    return pVar;
}

Address CalcPtr_Ext(HANDLE hProc, Address base, Offset offs[], Count lvl)
{
    Address product = base;
    for (Count i = 0; i < lvl; ++i)
    {
        ReadProcessMemory(hProc, (LPCVOID)product, &product, sizeof(Address), 0);
        product += offs[i];
    }
    return product;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
